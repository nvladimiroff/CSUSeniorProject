<?php

class NoMatchingParserException extends Exception {}

